const mongoose = require('mongoose');
const appointmentSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  doctorId: { type: mongoose.Schema.Types.ObjectId, ref: 'Doctor' },
  slot: String,
  status: { type: String, enum: ['pending', 'approved', 'rejected'], default: 'pending' },
  notes: String
});
module.exports = mongoose.model('Appointment', appointmentSchema);